*************************
HOW TO INSTALL THIS THEME
*************************

1. Copy the theme folder into the "App" folder of your SdCard
2. Turn on your Miyoo Mini and find the theme in the App section
3. Launch it. The miyoo will turn off once the process is finished.
4. Enjoy your new theme !


******************
YOU ARE A DESIGNER
******************

You want to use this to share your creation ?
Sure, it is easy. Just copy this theme and edit the folowing :

1. The theme folder name, do not let space in it
2. Edit the config.json file :
	label : Your theme title. Title convention suggered : "Theme - Your theme name"
	description : Theme name + Author
3. For the icon, make a 74x74 icon.png
4. Change the ressources in the data/miyoo/app


******************
Credits
******************
Music by Karl Casey @ White Bat Audio



******************
Questions? Comments?
******************

Send me an email at plasticleaf@outlook.com