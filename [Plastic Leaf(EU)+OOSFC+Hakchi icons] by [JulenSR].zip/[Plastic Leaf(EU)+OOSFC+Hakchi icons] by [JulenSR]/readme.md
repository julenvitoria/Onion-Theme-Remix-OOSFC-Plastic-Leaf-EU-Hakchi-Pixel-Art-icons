# `OOSFC by ytdcpndsgn (with custom bootscreen)`
# `+`
# `Plastic Leaf (EU) by leafflat`
# `+`
# `Screen_Off.png from PAC-MIYOO by tenlevels`
# `Theme Remix`
# `+`
# `Hakchi Pixel Art by faustbear icons`
# `+`
# `Some custom icons`